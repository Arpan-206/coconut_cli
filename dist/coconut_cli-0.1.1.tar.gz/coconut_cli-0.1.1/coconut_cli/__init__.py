__version__ = '0.1.0'
import os

DEST_DIR = os.path.expanduser('~')
DEST_PATH = os.path.join(DEST_DIR, '.coconut.yaml')